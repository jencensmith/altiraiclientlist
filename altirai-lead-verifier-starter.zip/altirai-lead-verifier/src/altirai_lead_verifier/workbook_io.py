from __future__ import annotations

from pathlib import Path
import pandas as pd


PREFERRED_SHEETS = ["Research Gaps", "Master Lead List", "Master Lead List Updated"]


def normalize_column_name(name: str) -> str:
    return str(name).strip().lower().replace(" ", "_").replace("/", "_")


def read_leads(input_path: Path) -> pd.DataFrame:
    sheets = pd.read_excel(input_path, sheet_name=None)
    sheet_name = next((s for s in PREFERRED_SHEETS if s in sheets), next(iter(sheets)))
    df = sheets[sheet_name].copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df


def ensure_columns(df: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    for col in columns:
        if col not in df.columns:
            df[col] = ""
    return df


def export_workbook(df: pd.DataFrame, research_log: pd.DataFrame, output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)

    a_fit = df[df["Lead Tier"].eq("A")].copy()
    b_fit = df[df["Lead Tier"].eq("B")].copy()
    maybe = df[df["Lead Tier"].isin(["C", "D"])].copy()
    disqualified = df[df["Lead Tier"].eq("Disqualified")].copy()
    needs_review = df[df["Human Review Needed"].eq("Yes")].copy()

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Master Lead List Updated", index=False)
        a_fit.to_excel(writer, sheet_name="A-Fit Leads", index=False)
        b_fit.to_excel(writer, sheet_name="B-Fit Leads", index=False)
        maybe.to_excel(writer, sheet_name="Maybe Future Leads", index=False)
        disqualified.to_excel(writer, sheet_name="Disqualified Leads", index=False)
        needs_review.to_excel(writer, sheet_name="Needs Human Review", index=False)
        research_log.to_excel(writer, sheet_name="Research Log", index=False)
