from __future__ import annotations

import re
from .config import Config
from .models import WebsiteEvidence, LeadClassification

US_STATE_NAMES = {
    "alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut",
    "delaware", "florida", "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa",
    "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts", "michigan",
    "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new hampshire",
    "new jersey", "new mexico", "new york", "north carolina", "north dakota", "ohio", "oklahoma",
    "oregon", "pennsylvania", "rhode island", "south carolina", "south dakota", "tennessee",
    "texas", "utah", "vermont", "virginia", "washington", "west virginia", "wisconsin", "wyoming",
}


def as_text(value) -> str:
    return str(value or "").strip()


def contains_any(text: str, keywords: tuple[str, ...]) -> bool:
    lower = text.lower()
    return any(k.lower() in lower for k in keywords)


def detect_services(text: str, config: Config) -> list[str]:
    found = []
    lower = text.lower()
    for service, keywords in config.service_keywords.items():
        if any(k in lower for k in keywords):
            found.append(service)
    return found


def estimate_volume(row: dict) -> str:
    existing = as_text(row.get("Estimated Listings per Month")) or as_text(row.get("Estimated listing volume"))
    if existing:
        return existing
    cubicasa = as_text(row.get("Cubicasa Floor Plan Count or Activity Signal")) or as_text(row.get("Cubicasa activity"))
    numbers = [int(n) for n in re.findall(r"\d+", cubicasa)]
    if numbers:
        return f"Cubicasa proxy: {max(numbers)} floor plans/activity count"
    return "Unconfirmed"


def detect_multi_state(text: str, config: Config) -> str:
    lower = text.lower()
    if contains_any(lower, config.multi_state_keywords):
        return "Yes"
    state_hits = [state for state in US_STATE_NAMES if re.search(rf"\b{re.escape(state)}\b", lower)]
    if len(set(state_hits)) >= 4:
        return "Yes"
    return "Unclear"


def classify_lead(row: dict, evidence: WebsiteEvidence, config: Config) -> LeadClassification:
    text = evidence.page_text or ""
    services = detect_services(text, config)

    state = as_text(row.get("State")) or as_text(row.get("state"))
    if state in config.excluded_states:
        return LeadClassification(
            services_offered=services,
            real_estate_media_focus="Unclear",
            locally_owned="Unclear",
            multi_state="Unclear",
            recent_activity_signal="Unclear",
            icp_fit_score=1,
            lead_tier="Disqualified",
            reason_for_score="Michigan company or market is excluded.",
            confidence_level="Strong",
            human_review_needed="No",
        )

    real_estate_focus = "Yes" if contains_any(text, config.real_estate_keywords) else "Unclear"
    multi_state = detect_multi_state(text, config)
    locally_owned = "Likely" if multi_state != "Yes" and evidence.website_active == "Yes" else "Unclear"
    recent_activity = "Likely active website" if evidence.website_active == "Yes" else "Unclear"

    score = 1
    reasons = []

    if evidence.website_active == "No":
        reasons.append("Website inactive or unreachable.")
    if real_estate_focus == "Yes":
        score += 1
        reasons.append("Website has real estate media signals.")
    if len(services) >= 3:
        score += 1
        reasons.append("Multiple real estate media services found.")
    if len(services) >= 5:
        score += 1
        reasons.append("Broad service mix found.")
    if evidence.social_links:
        score += 1
        reasons.append("Social links found, suggesting public activity.")
    if multi_state == "Yes":
        score = 1
        reasons.append("Potential multi-state or national footprint.")
    if real_estate_focus != "Yes" and evidence.website_active == "Yes":
        score = min(score, 2)
        reasons.append("Real estate media focus is not clearly verified.")

    score = max(1, min(5, score))
    tier = {5: "A", 4: "B", 3: "C", 2: "D", 1: "Disqualified"}[score]

    confidence = "Strong" if evidence.website_active == "Yes" and len(evidence.source_urls) >= 3 and real_estate_focus == "Yes" else "Medium"
    if evidence.website_active != "Yes" or not evidence.source_urls:
        confidence = "Weak"

    review_reasons = []
    if locally_owned != "Confirmed":
        review_reasons.append("Ownership not confirmed")
    if not evidence.emails and evidence.contact_form_url == "Unconfirmed":
        review_reasons.append("No public email or contact form found")
    if multi_state == "Unclear":
        review_reasons.append("Multi-state risk unclear")

    return LeadClassification(
        services_offered=services,
        real_estate_media_focus=real_estate_focus,
        locally_owned=locally_owned,
        multi_state=multi_state,
        recent_activity_signal=recent_activity,
        icp_fit_score=score,
        lead_tier=tier,
        reason_for_score=" ".join(reasons) or "Insufficient evidence.",
        confidence_level=confidence,
        human_review_needed="Yes" if review_reasons else "No",
        human_review_reason="; ".join(review_reasons),
    )
