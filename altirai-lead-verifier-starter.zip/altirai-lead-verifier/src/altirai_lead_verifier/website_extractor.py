from __future__ import annotations

import re
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

from .config import Config
from .models import WebsiteEvidence

EMAIL_RE = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.IGNORECASE)
SOCIAL_DOMAINS = ("facebook.com", "instagram.com", "linkedin.com", "youtube.com", "tiktok.com", "x.com", "twitter.com")
CONTACT_WORDS = ("contact", "book", "quote", "schedule", "inquire", "request")
ABOUT_WORDS = ("about", "team", "our-story", "story")
SERVICE_WORDS = ("service", "pricing", "real-estate", "portfolio")


def clean_url(url: str) -> str:
    url = str(url or "").strip()
    if not url:
        return ""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


def same_domain(base: str, candidate: str) -> bool:
    return urlparse(base).netloc.replace("www.", "") == urlparse(candidate).netloc.replace("www.", "")


def fetch_page(url: str, config: Config) -> tuple[str, str]:
    headers = {"User-Agent": config.user_agent}
    resp = requests.get(url, headers=headers, timeout=config.request_timeout_seconds, allow_redirects=True)
    resp.raise_for_status()
    return resp.url, resp.text


def soup_text(html: str) -> str:
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()
    return " ".join(soup.get_text(" ").split())


def discover_links(base_url: str, html: str) -> list[str]:
    soup = BeautifulSoup(html, "lxml")
    links: list[str] = []
    for a in soup.find_all("a", href=True):
        href = urljoin(base_url, a["href"])
        lower = href.lower()
        if same_domain(base_url, href) and any(word in lower for word in CONTACT_WORDS + ABOUT_WORDS + SERVICE_WORDS):
            links.append(href.split("#")[0])
    return list(dict.fromkeys(links))


def extract_social_links(base_url: str, html: str) -> list[str]:
    soup = BeautifulSoup(html, "lxml")
    links = []
    for a in soup.find_all("a", href=True):
        href = urljoin(base_url, a["href"])
        if any(domain in href.lower() for domain in SOCIAL_DOMAINS):
            links.append(href.split("?")[0])
    return list(dict.fromkeys(links))


def find_contact_url(urls: list[str]) -> str:
    for url in urls:
        if "contact" in url.lower():
            return url
    for url in urls:
        if any(word in url.lower() for word in CONTACT_WORDS):
            return url
    return "Unconfirmed"


def extract_website_evidence(website: str, config: Config) -> WebsiteEvidence:
    website = clean_url(website)
    evidence = WebsiteEvidence()
    if not website:
        evidence.error = "Missing website"
        evidence.website_active = "Unclear"
        return evidence

    try:
        final_url, html = fetch_page(website, config)
        evidence.website_active = "Yes"
        evidence.source_urls.append(final_url)
        evidence.social_links.extend(extract_social_links(final_url, html))
        evidence.emails.extend(EMAIL_RE.findall(html))
        text_chunks = [soup_text(html)]

        candidate_links = discover_links(final_url, html)[: config.max_pages_per_company - 1]
        evidence.contact_form_url = find_contact_url(candidate_links + [final_url])

        for link in candidate_links:
            try:
                page_url, page_html = fetch_page(link, config)
                evidence.source_urls.append(page_url)
                evidence.social_links.extend(extract_social_links(page_url, page_html))
                evidence.emails.extend(EMAIL_RE.findall(page_html))
                text_chunks.append(soup_text(page_html))
            except Exception as exc:
                continue

        evidence.page_text = " ".join(text_chunks)[:25000]
        evidence.emails = sorted(set(evidence.emails))
        evidence.social_links = sorted(set(evidence.social_links))
        evidence.source_urls = list(dict.fromkeys(evidence.source_urls))
        return evidence
    except Exception as exc:
        evidence.website_active = "No"
        evidence.error = str(exc)
        return evidence
