from dataclasses import dataclass, field


@dataclass
class WebsiteEvidence:
    website_active: str = "Unclear"
    source_urls: list[str] = field(default_factory=list)
    page_text: str = ""
    emails: list[str] = field(default_factory=list)
    contact_form_url: str = "Unconfirmed"
    social_links: list[str] = field(default_factory=list)
    error: str = ""


@dataclass
class LeadClassification:
    services_offered: list[str] = field(default_factory=list)
    real_estate_media_focus: str = "Unclear"
    locally_owned: str = "Unclear"
    multi_state: str = "Unclear"
    recent_activity_signal: str = "Unclear"
    owner_founder_name: str = "Unconfirmed"
    icp_fit_score: int = 1
    lead_tier: str = "Disqualified"
    reason_for_score: str = ""
    confidence_level: str = "Weak"
    human_review_needed: str = "Yes"
    human_review_reason: str = ""
