from __future__ import annotations

import argparse
from datetime import datetime
from pathlib import Path

import pandas as pd

from .config import Config
from .models import WebsiteEvidence
from .scoring import classify_lead, estimate_volume
from .website_extractor import extract_website_evidence
from .workbook_io import read_leads, ensure_columns, export_workbook

OUTPUT_COLUMNS = [
    "Website Active",
    "Services Offered",
    "Real Estate Media Focus",
    "Locally Owned",
    "Multi-State",
    "Recent Activity Signal",
    "Owner/founder name",
    "Contact Email",
    "Contact Form URL",
    "Social Links",
    "Estimated Listings per Month",
    "ICP Fit Score",
    "Lead Tier",
    "Reason for Score",
    "Verification Sources",
    "Confidence Level",
    "Human Review Needed",
    "Human Review Reason",
]


def get_first(row: pd.Series, candidates: list[str]) -> str:
    for col in candidates:
        if col in row.index and pd.notna(row[col]) and str(row[col]).strip():
            return str(row[col]).strip()
    return ""


def process_row(row: pd.Series, config: Config) -> tuple[dict, dict]:
    row_dict = row.to_dict()
    company = get_first(row, ["Company Name", "Company", "Business Name", "Name"])
    website = get_first(row, ["Website", "Website URL", "Direct Website Link", "URL"])

    evidence = extract_website_evidence(website, config) if website else WebsiteEvidence(error="Missing website")
    classification = classify_lead(row_dict, evidence, config)

    updated = dict(row_dict)
    updated["Website Active"] = evidence.website_active
    updated["Services Offered"] = ", ".join(classification.services_offered) if classification.services_offered else "Unconfirmed"
    updated["Real Estate Media Focus"] = classification.real_estate_media_focus
    updated["Locally Owned"] = classification.locally_owned
    updated["Multi-State"] = classification.multi_state
    updated["Recent Activity Signal"] = classification.recent_activity_signal
    updated["Owner/founder name"] = classification.owner_founder_name
    updated["Contact Email"] = ", ".join(evidence.emails) if evidence.emails else "Unconfirmed"
    updated["Contact Form URL"] = evidence.contact_form_url
    updated["Social Links"] = ", ".join(evidence.social_links) if evidence.social_links else "Unconfirmed"
    updated["Estimated Listings per Month"] = estimate_volume(row_dict)
    updated["ICP Fit Score"] = classification.icp_fit_score
    updated["Lead Tier"] = classification.lead_tier
    updated["Reason for Score"] = classification.reason_for_score
    updated["Verification Sources"] = ", ".join(evidence.source_urls) if evidence.source_urls else "Unconfirmed"
    updated["Confidence Level"] = classification.confidence_level
    updated["Human Review Needed"] = classification.human_review_needed
    updated["Human Review Reason"] = classification.human_review_reason

    log = {
        "Company Name": company,
        "Website": website,
        "Processed At": datetime.now().isoformat(timespec="seconds"),
        "Website Active": evidence.website_active,
        "Sources Checked": len(evidence.source_urls),
        "Error": evidence.error,
        "Score": classification.icp_fit_score,
        "Tier": classification.lead_tier,
        "Human Review Needed": classification.human_review_needed,
    }
    return updated, log


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify Altirai lead list workbook.")
    parser.add_argument("--input", required=True, help="Input Excel workbook path")
    parser.add_argument("--output", required=True, help="Output Excel workbook path")
    parser.add_argument("--batch-size", type=int, default=25, help="Number of rows to process")
    parser.add_argument("--start-row", type=int, default=0, help="Zero-based row index to start processing")
    args = parser.parse_args()

    config = Config(batch_size=args.batch_size)
    input_path = Path(args.input)
    output_path = Path(args.output)

    df = read_leads(input_path)
    df = ensure_columns(df, OUTPUT_COLUMNS)

    end = min(args.start_row + args.batch_size, len(df))
    logs = []
    updated_rows = []

    for idx in range(args.start_row, end):
        updated, log = process_row(df.iloc[idx], config)
        updated_rows.append((idx, updated))
        logs.append(log)
        print(f"Processed row {idx + 1}: {log.get('Company Name')} -> {log.get('Tier')} / {log.get('Score')}")

    for idx, updated in updated_rows:
        for key, value in updated.items():
            df.at[idx, key] = value

    research_log = pd.DataFrame(logs)
    export_workbook(df, research_log, output_path)
    print(f"Exported workbook: {output_path}")


if __name__ == "__main__":
    main()
