from dataclasses import dataclass, field


@dataclass(frozen=True)
class Config:
    excluded_states: set[str] = field(default_factory=lambda: {"MI", "Michigan"})
    batch_size: int = 25
    request_timeout_seconds: int = 12
    max_pages_per_company: int = 5
    user_agent: str = "AltiraiLeadVerifier/0.1 (+https://altirai.com)"

    real_estate_keywords: tuple[str, ...] = (
        "real estate photography",
        "real estate media",
        "property photography",
        "listing photography",
        "mls photography",
        "architectural photography",
        "real estate video",
        "matterport",
        "floor plan",
        "drone photography",
        "aerial photography",
        "virtual tour",
        "3d tour",
        "twilight",
        "zillow",
        "realtor",
        "brokerage",
    )

    service_keywords: dict[str, tuple[str, ...]] = field(default_factory=lambda: {
        "Photo": ("photo", "photography", "hdr", "listing photos"),
        "Video": ("video", "walkthrough", "cinematic", "reel"),
        "Drone": ("drone", "aerial"),
        "Floor Plans": ("floor plan", "floorplan", "cubicasa"),
        "3D / Matterport": ("matterport", "3d tour", "virtual tour"),
        "Virtual Staging": ("virtual staging", "staging"),
        "Twilight": ("twilight", "day to dusk", "dusk"),
        "Listing Websites": ("listing website", "property website", "single property website"),
    })

    multi_state_keywords: tuple[str, ...] = (
        "nationwide",
        "national",
        "across the country",
        "multiple states",
        "locations nationwide",
        "franchise",
    )
