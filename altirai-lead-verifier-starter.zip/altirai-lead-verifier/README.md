# Altirai Lead Verifier

A starter Python project for verifying Cubicasa-based real estate media company leads for Altirai Studios.

This repo is designed to be uploaded to GitHub and improved with Codex.

## What it does

- Reads an input Excel workbook
- Processes leads in batches
- Verifies websites when available
- Extracts public website text, emails, contact page URLs, and social links
- Classifies real estate media focus, local/multi-state risk, services, and fit
- Scores each lead from 1 to 5
- Exports a new Excel workbook with lead tabs and a research log

## What it does not do yet

- It does not guarantee perfect web search results for missing websites
- It does not enrich private emails
- It does not bypass paywalls, logins, or rate limits
- It does not replace human review for A/B leads

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
python -m altirai_lead_verifier.main \
  --input "input/Altirai Contact List.xlsx" \
  --output "output/altirai_verified_leads.xlsx" \
  --batch-size 25
```

## Suggested workflow

1. Put the latest workbook in `/input`.
2. Run a 25-row batch first.
3. Review `Needs Human Review` and `Research Log`.
4. Ask Codex to improve weak parts of the pipeline.
5. Scale to 50 or 100 rows only after QA looks good.
