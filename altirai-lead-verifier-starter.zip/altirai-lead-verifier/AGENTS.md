# Codex Instructions

## Project purpose
Build and improve a Python lead verification pipeline for Altirai Studios.

Altirai Studios targets locally owned real estate media companies that need production support across photo editing, video editing, floor plans, 3D tours, listing websites, and delivery workflows.

## Hard rules
- Do not fabricate data.
- Mark unverifiable fields as `Unconfirmed` or `Unclear`.
- Every verified claim should include a source URL.
- Exclude Michigan companies and Michigan markets.
- Exclude multi-state or national companies unless flagged as strategic/non-standard.
- Prefer confidence scoring over guessing.
- Do not overwrite the original workbook.

## Build priorities
1. Make workbook ingestion robust across messy column names.
2. Improve website discovery for rows missing a website.
3. Improve service extraction from website text.
4. Improve local ownership and multi-state risk detection.
5. Improve scoring explainability.
6. Add tests before major refactors.

## Output expectation
Every run should create a new timestamped workbook with:
- Master Lead List Updated
- A-Fit Leads
- B-Fit Leads
- Maybe / Future Leads
- Disqualified Leads
- Needs Human Review
- Research Log
